# pages/analytics.py
import customtkinter as ctk
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from datetime import datetime, timedelta
import seaborn as sns
import numpy as np

class AnalyticsPage(ctk.CTkFrame):
    def __init__(self, parent, data):
        super().__init__(parent, corner_radius=15)
        self.data = data
        self.setup_analytics_page()
    
    def setup_analytics_page(self):
        # Configure grid
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)
        
        # Header
        header_frame = ctk.CTkFrame(self, corner_radius=12, height=80)
        header_frame.grid(row=0, column=0, sticky="ew", padx=20, pady=20)
        header_frame.grid_propagate(False)
        
        ctk.CTkLabel(header_frame, text="📈 Analytics & Insights", 
                    font=("Arial", 24, "bold")).pack(pady=20)
        
        # Analytics container
        self.analytics_container = ctk.CTkScrollableFrame(self, corner_radius=12)
        self.analytics_container.grid(row=1, column=0, sticky="nsew", padx=20, pady=(0, 20))
        self.analytics_container.grid_columnconfigure(0, weight=1)
        
        self.create_analytics_dashboard()
    
    def create_analytics_dashboard(self):
        # Quick stats row
        stats_frame = ctk.CTkFrame(self.analytics_container, corner_radius=10)
        stats_frame.grid(row=0, column=0, sticky="ew", padx=10, pady=10)
        stats_frame.grid_columnconfigure((0, 1, 2, 3), weight=1)
        
        total_habits = len(self.data.get("habits", []))
        total_completions = sum(h.get("total_completions", 0) for h in self.data.get("habits", []))
        current_streak = self.calculate_current_streak()
        aura_points = self.data.get("aura_points", 0)
        
        self.create_metric_card(stats_frame, "Total Habits", total_habits, "📋", 0, 0)
        self.create_metric_card(stats_frame, "Total Completions", total_completions, "✅", 0, 1)
        self.create_metric_card(stats_frame, "Current Streak", f"{current_streak} days", "🔥", 0, 2)
        self.create_metric_card(stats_frame, "Aura Power", aura_points, "⚡", 0, 3)
        
        # Charts row
        charts_frame = ctk.CTkFrame(self.analytics_container, corner_radius=10)
        charts_frame.grid(row=1, column=0, sticky="ew", padx=10, pady=10)
        charts_frame.grid_columnconfigure((0, 1), weight=1)
        
        # Progress chart
        self.create_progress_chart(charts_frame)
        
        # Habits distribution chart
        self.create_habits_chart(charts_frame)
    
    def create_metric_card(self, parent, title, value, emoji, row, col):
        card = ctk.CTkFrame(parent, corner_radius=8, height=100)
        card.grid(row=row, column=col, padx=10, pady=10, sticky="nsew")
        card.grid_propagate(False)
        
        ctk.CTkLabel(card, text=emoji, font=("Arial", 24)).pack(pady=(15, 5))
        ctk.CTkLabel(card, text=str(value), font=("Arial", 20, "bold"), 
                    text_color="#3b82f6").pack(pady=5)
        ctk.CTkLabel(card, text=title, font=("Arial", 12), 
                    text_color="gray").pack(pady=(0, 15))
    
    def create_progress_chart(self, parent):
        chart_frame = ctk.CTkFrame(parent, corner_radius=8)
        chart_frame.grid(row=0, column=0, padx=5, pady=5, sticky="nsew")
        
        ctk.CTkLabel(chart_frame, text="30-Day Progress", 
                    font=("Arial", 16, "bold")).pack(pady=10)
        
        # Create matplotlib figure
        fig, ax = plt.subplots(figsize=(6, 3), dpi=100)
        
        # Get last 30 days data
        dates, counts = self.get_30_day_data()
        
        if dates:
            # Create gradient line
            x = range(len(dates))
            y = counts
            
            # Plot with gradient effect
            for i in range(len(x)-1):
                ax.plot(x[i:i+2], y[i:i+2], color=plt.cm.viridis(i/len(x)), linewidth=3)
            
            ax.fill_between(x, y, alpha=0.3, color='#3b82f6')
            ax.set_xticks(x[::7])
            ax.set_xticklabels([d.strftime('%m/%d') for d in dates[::7]], rotation=45)
            ax.grid(True, alpha=0.3)
            ax.set_ylabel('Habits Completed')
        else:
            ax.text(0.5, 0.5, 'No data yet!\nComplete some habits to see progress', 
                   ha='center', va='center', transform=ax.transAxes, fontsize=12)
        
        fig.tight_layout()
        
        # Embed in tkinter
        canvas = FigureCanvasTkAgg(fig, chart_frame)
        canvas.draw()
        canvas.get_tk_widget().pack(fill="both", expand=True, padx=10, pady=10)
    
    def create_habits_chart(self, parent):
        chart_frame = ctk.CTkFrame(parent, corner_radius=8)
        chart_frame.grid(row=0, column=1, padx=5, pady=5, sticky="nsew")
        
        ctk.CTkLabel(chart_frame, text="Habits Performance", 
                    font=("Arial", 16, "bold")).pack(pady=10)
        
        fig, ax = plt.subplots(figsize=(6, 3), dpi=100)
        
        habits = self.data.get("habits", [])
        if habits:
            names = [h["name"][:15] + "..." if len(h["name"]) > 15 else h["name"] for h in habits]
            completions = [h.get("total_completions", 0) for h in habits]
            streaks = [h.get("streak", 0) for h in habits]
            
            x = range(len(names))
            bars = ax.bar(x, completions, color=plt.cm.Set3(np.linspace(0, 1, len(names))))
            
            # Add streak annotations
            for i, (bar, streak) in enumerate(zip(bars, streaks)):
                height = bar.get_height()
                ax.text(bar.get_x() + bar.get_width()/2., height + 0.1,
                       f'🔥{streak}', ha='center', va='bottom', fontsize=8)
            
            ax.set_xticks(x)
            ax.set_xticklabels(names, rotation=45, ha='right')
            ax.set_ylabel('Total Completions')
        else:
            ax.text(0.5, 0.5, 'No habits yet!\nAdd habits to see performance', 
                   ha='center', va='center', transform=ax.transAxes, fontsize=12)
        
        fig.tight_layout()
        
        canvas = FigureCanvasTkAgg(fig, chart_frame)
        canvas.draw()
        canvas.get_tk_widget().pack(fill="both", expand=True, padx=10, pady=10)
    
    def get_30_day_data(self):
        history = self.data.get("history", {})
        if not history:
            return [], []
        
        end_date = datetime.now().date()
        start_date = end_date - timedelta(days=29)
        
        dates = []
        counts = []
        
        for i in range(30):
            current_date = start_date + timedelta(days=i)
            date_str = current_date.strftime("%Y-%m-%d")
            count = len(history.get(date_str, []))
            dates.append(current_date)
            counts.append(count)
        
        return dates, counts
    
    def calculate_current_streak(self):
        history = self.data.get("history", {})
        if not history:
            return 0
        
        dates = sorted([datetime.strptime(d, "%Y-%m-%d").date() for d in history.keys()])
        today = datetime.now().date()
        streak = 0
        
        # Check consecutive days from today backwards
        current_date = today
        while current_date in dates:
            streak += 1
            current_date -= timedelta(days=1)
        
        return streak