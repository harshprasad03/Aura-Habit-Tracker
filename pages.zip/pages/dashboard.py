# pages/dashboard.py - CORRECTED VERSION
import customtkinter as ctk
from datetime import datetime, timedelta
from data_handler import load_data, save_data
from components.level_system import LevelSystem

class DashboardPage(ctk.CTkFrame):
    def __init__(self, parent, data):
        super().__init__(parent, corner_radius=15, fg_color=("gray90", "gray13"))
        self.data = data
        self.level_system = LevelSystem()
        self.setup_dashboard()
    
    def setup_dashboard(self):
        # Configure grid
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)
        
        # Welcome section
        self.create_welcome_section()
        
        # Main content area
        content_frame = ctk.CTkFrame(self, fg_color="transparent")
        content_frame.grid(row=1, column=0, sticky="nsew", padx=20, pady=(0, 20))
        content_frame.grid_columnconfigure(0, weight=1)
        content_grid = ctk.CTkFrame(content_frame, fg_color="transparent")
        content_grid.pack(fill="both", expand=True)
        content_grid.grid_columnconfigure((0, 1), weight=1)
        content_grid.grid_rowconfigure(0, weight=1)
        
        # Left column - Stats
        left_frame = ctk.CTkFrame(content_grid, corner_radius=12)
        left_frame.grid(row=0, column=0, sticky="nsew", padx=(0, 10), pady=0)
        left_frame.grid_columnconfigure(0, weight=1)
        
        # Right column - Daily Focus
        right_frame = ctk.CTkFrame(content_grid, corner_radius=12)
        right_frame.grid(row=0, column=1, sticky="nsew", padx=(10, 0), pady=0)
        right_frame.grid_columnconfigure(0, weight=1)
        
        # Create content for both columns
        self.create_stats_section(left_frame)
        self.create_daily_focus(right_frame)
    
    def create_welcome_section(self):
        welcome_frame = ctk.CTkFrame(self, corner_radius=12, height=120)
        welcome_frame.grid(row=0, column=0, sticky="ew", padx=20, pady=20)
        welcome_frame.grid_columnconfigure(1, weight=1)
        welcome_frame.grid_propagate(False)
        
        # Level and progress
        aura_points = self.data.get("aura_points", 0)
        level, level_info = self.level_system.get_current_level(aura_points)
        progress = self.level_system.get_level_progress(aura_points)
        
        # Level badge
        level_badge = ctk.CTkFrame(welcome_frame, corner_radius=20, 
                                 fg_color=level_info["color"], width=80, height=80)
        level_badge.grid(row=0, column=0, rowspan=2, padx=25, pady=20)
        level_badge.grid_propagate(False)
        
        ctk.CTkLabel(level_badge, text=f"{level}", font=("Arial", 20, "bold"), 
                    text_color="white").place(relx=0.5, rely=0.4, anchor="center")
        ctk.CTkLabel(level_badge, text="LEVEL", font=("Arial", 10), 
                    text_color="white").place(relx=0.5, rely=0.7, anchor="center")
        
        # Welcome text
        character_name = self.data.get("character", "Warrior")
        ctk.CTkLabel(welcome_frame, 
                    text=f"Welcome back, {character_name.capitalize()}!",
                    font=("Arial", 22, "bold")).grid(row=0, column=1, sticky="sw", padx=10, pady=(20, 0))
        
        ctk.CTkLabel(welcome_frame, 
                    text=f"⚡ {aura_points} Aura Points • {int(progress*100)}% to Level {level+1}",
                    font=("Arial", 14), text_color="gray").grid(row=1, column=1, sticky="nw", padx=10, pady=(0, 20))
        
        # Progress bar
        progress_frame = ctk.CTkFrame(welcome_frame, fg_color="transparent")
        progress_frame.grid(row=2, column=0, columnspan=2, sticky="ew", padx=25, pady=(0, 15))
        
        ctk.CTkLabel(progress_frame, text=f"Level {level}", font=("Arial", 12)).pack(side="left")
        ctk.CTkLabel(progress_frame, text=f"Level {level+1}", font=("Arial", 12)).pack(side="right")
        
        progress_bar = ctk.CTkProgressBar(progress_frame, height=8, corner_radius=4)
        progress_bar.pack(fill="x", pady=5)
        progress_bar.set(progress)
        progress_bar.configure(progress_color=level_info["color"])
    
    def create_stats_section(self, parent):
        # Stats header
        ctk.CTkLabel(parent, text="📊 Your Stats", 
                    font=("Arial", 18, "bold")).pack(pady=(20, 15))
        
        # Stats grid container
        stats_container = ctk.CTkFrame(parent, fg_color="transparent")
        stats_container.pack(fill="both", expand=True, padx=15, pady=(0, 20))
        stats_container.grid_columnconfigure((0, 1), weight=1)
        stats_container.grid_rowconfigure((0, 1), weight=1)
        
        # Calculate stats
        total_habits = len(self.data.get("habits", []))
        total_completions = sum(h.get("total_completions", 0) for h in self.data.get("habits", []))
        current_streak = self.calculate_current_streak()
        aura_points = self.data.get("aura_points", 0)
        
        # Create stat cards in 2x2 grid
        self.create_stat_card(stats_container, "Total Habits", total_habits, "📋", "#3b82f6", 0, 0)
        self.create_stat_card(stats_container, "Total Completions", total_completions, "✅", "#10b981", 0, 1)
        self.create_stat_card(stats_container, "Current Streak", f"{current_streak} days", "🔥", "#f59e0b", 1, 0)
        self.create_stat_card(stats_container, "Aura Power", aura_points, "⚡", "#8b5cf6", 1, 1)
    
    def create_stat_card(self, parent, title, value, emoji, color, row, col):
        card = ctk.CTkFrame(parent, corner_radius=12, height=110)
        card.grid(row=row, column=col, padx=8, pady=8, sticky="nsew")
        card.grid_propagate(False)
        
        # Colored accent bar
        accent = ctk.CTkFrame(card, corner_radius=6, fg_color=color, height=4)
        accent.place(relx=0.05, rely=0.15, relwidth=0.9)
        
        # Content frame
        content = ctk.CTkFrame(card, fg_color="transparent")
        content.place(relx=0.5, rely=0.55, anchor="center", relwidth=0.9, relheight=0.7)
        
        # Emoji and value
        emoji_frame = ctk.CTkFrame(content, fg_color="transparent")
        emoji_frame.pack(fill="x", pady=(0, 5))
        
        ctk.CTkLabel(emoji_frame, text=emoji, font=("Arial", 16)).pack(side="left")
        ctk.CTkLabel(emoji_frame, text=str(value), font=("Arial", 20, "bold"), 
                    text_color=color).pack(side="right")
        
        # Title
        ctk.CTkLabel(content, text=title, font=("Arial", 12), 
                    text_color="gray").pack(anchor="w")
    
    def create_daily_focus(self, parent):
        focus_frame = ctk.CTkFrame(parent, corner_radius=12)
        focus_frame.pack(fill="both", expand=True, padx=0, pady=0)
        
        ctk.CTkLabel(focus_frame, text="🎯 Today's Focus", 
                    font=("Arial", 18, "bold")).pack(pady=(20, 15))
        
        # Focus habits container
        focus_container = ctk.CTkScrollableFrame(focus_frame, fg_color="transparent")
        focus_container.pack(fill="both", expand=True, padx=15, pady=(0, 15))
        
        habits = self.data.get("habits", [])
        if habits:
            priority_habits = sorted(habits, key=lambda x: x.get('streak', 0), reverse=True)[:3]
            
            for i, habit in enumerate(priority_habits):
                self.create_focus_habit(focus_container, habit, i)
        else:
            empty_frame = ctk.CTkFrame(focus_container, fg_color="transparent", height=100)
            empty_frame.pack(fill="x", pady=10)
            empty_frame.grid_propagate(False)
            
            ctk.CTkLabel(empty_frame, text="📝", font=("Arial", 32)).pack(pady=(10, 5))
            ctk.CTkLabel(empty_frame, text="No habits yet!", 
                        font=("Arial", 14), text_color="gray").pack()
            ctk.CTkLabel(empty_frame, text="Add habits to see focus", 
                        font=("Arial", 12), text_color="gray").pack()
    
    def create_focus_habit(self, parent, habit, index):
        habit_frame = ctk.CTkFrame(parent, corner_radius=10, height=70)
        habit_frame.pack(fill="x", pady=6)
        habit_frame.grid_propagate(False)
        habit_frame.grid_columnconfigure(0, weight=1)
        
        # Habit name and streak
        main_frame = ctk.CTkFrame(habit_frame, fg_color="transparent")
        main_frame.grid(row=0, column=0, sticky="ew", padx=15, pady=10)
        main_frame.grid_columnconfigure(0, weight=1)
        
        ctk.CTkLabel(main_frame, text=habit["name"], 
                    font=("Arial", 14, "bold")).grid(row=0, column=0, sticky="w")
        
        streak = habit.get('streak', 0)
        streak_text = f"🔥 {streak} day streak"
        ctk.CTkLabel(main_frame, text=streak_text, 
                    font=("Arial", 11), text_color="gray").grid(row=1, column=0, sticky="w", pady=(2, 0))
        
        # Progress indicator
        progress = min(streak / 7, 1.0)
        progress_circle = ctk.CTkFrame(habit_frame, width=30, height=30, 
                                     corner_radius=15, fg_color="#10b981" if progress >= 1.0 else "#3b82f6")
        progress_circle.grid(row=0, column=1, padx=15, pady=20)
        progress_circle.grid_propagate(False)
        
        ctk.CTkLabel(progress_circle, text=str(streak), font=("Arial", 10, "bold"), 
                    text_color="white").place(relx=0.5, rely=0.5, anchor="center")
    
    def calculate_current_streak(self):
        history = self.data.get("history", {})
        if not history:
            return 0
        
        dates = sorted([datetime.strptime(d, "%Y-%m-%d").date() for d in history.keys()])
        today = datetime.now().date()
        streak = 0
        
        current_date = today
        while current_date in dates:
            streak += 1
            current_date -= timedelta(days=1)
        
        return streak