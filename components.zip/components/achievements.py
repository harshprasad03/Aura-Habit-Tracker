# components/achievements.py
class AchievementSystem:
    ACHIEVEMENTS = {
        "first_habit": {"name": "First Step", "desc": "Complete your first habit", "icon": "🌟", "color": "#fbbf24"},
        "week_streak": {"name": "Week Warrior", "desc": "7-day streak", "icon": "🔥", "color": "#ef4444"},
        "habit_master": {"name": "Habit Master", "desc": "Create 5 habits", "icon": "🏆", "color": "#8b5cf6"},
        "consistent": {"name": "Consistent", "desc": "Complete habits 3 days in a row", "icon": "⚡", "color": "#10b981"}
    }
    
    def check_achievements(self, data):
        unlocked = []
        history = data.get("history", {})
        habits = data.get("habits", [])
        
        # Initialize achievements if not exists
        if "_achievements" not in data:
            data["_achievements"] = {}
        
        # Check first habit
        if not data["_achievements"].get("first_habit") and any(len(v) > 0 for v in history.values()):
            unlocked.append("first_habit")
            data["_achievements"]["first_habit"] = True
        
        # Check week streak
        current_streak = self.calculate_streak(history)
        if not data["_achievements"].get("week_streak") and current_streak >= 7:
            unlocked.append("week_streak")
            data["_achievements"]["week_streak"] = True
        
        # Check habit master
        if not data["_achievements"].get("habit_master") and len(habits) >= 5:
            unlocked.append("habit_master")
            data["_achievements"]["habit_master"] = True
        
        # Check consistent
        if not data["_achievements"].get("consistent") and current_streak >= 3:
            unlocked.append("consistent")
            data["_achievements"]["consistent"] = True
        
        return unlocked
    
    def calculate_streak(self, history):
        from datetime import datetime, timedelta
        if not history:
            return 0
        
        dates = sorted([datetime.strptime(d, "%Y-%m-%d").date() for d in history.keys()])
        today = datetime.now().date()
        streak = 0
        
        current_date = today
        while current_date in dates:
            streak += 1
            current_date -= timedelta(days=1)
        
        return streak