# components/sidebar.py
import customtkinter as ctk
from components.level_system import LevelSystem

class NavigationSidebar(ctk.CTkFrame):
    def __init__(self, parent, switch_callback):
        super().__init__(parent, corner_radius=15, width=200)
        self.switch_callback = switch_callback
        self.active_page = "dashboard"
        self.setup_sidebar()
    
    def setup_sidebar(self):
        # Title
        ctk.CTkLabel(self, text="AURA TRACKER", 
                    font=("Arial", 20, "bold"), 
                    text_color="#3b82f6").pack(pady=(30, 20))
        
        # Navigation buttons
        nav_items = [
            ("📊 Dashboard", "dashboard"),
            ("✅ Habits", "habits"), 
            ("📈 Analytics", "analytics"),
            ("🎭 Character", "character")
        ]
        
        self.nav_buttons = {}
        for text, page in nav_items:
            btn = ctk.CTkButton(self, text=text, font=("Arial", 14),
                              command=lambda p=page: self.switch_callback(p),
                              fg_color="transparent", hover_color="#2a2a2a",
                              anchor="w", height=40)
            btn.pack(fill="x", padx=10, pady=5)
            self.nav_buttons[page] = btn
        
        self.set_active_page(self.active_page)
        
        # Enhanced aura display in sidebar
        self.aura_frame = ctk.CTkFrame(self, corner_radius=12, fg_color="#1e3a8a")
        self.aura_frame.pack(side="bottom", fill="x", padx=10, pady=20)

        # Aura content with better design
        aura_content = ctk.CTkFrame(self.aura_frame, fg_color="transparent")
        aura_content.pack(fill="x", padx=15, pady=15)

        ctk.CTkLabel(aura_content, text="⚡ AURA POWER", 
                    font=("Arial", 12, "bold"), text_color="#93c5fd").pack(anchor="w")
        self.aura_label = ctk.CTkLabel(aura_content, text="0", 
                                      font=("Arial", 28, "bold"), text_color="#ffffff")
        self.aura_label.pack(anchor="w", pady=(5, 0))

        # Add level indicator
        self.level_system = LevelSystem()
        level, level_info = self.level_system.get_current_level(0)
        self.level_label = ctk.CTkLabel(aura_content, text=f"Level {level} • {level_info['title']}", 
                            font=("Arial", 10), text_color="#bfdbfe")
        self.level_label.pack(anchor="w")
    
    def set_active_page(self, page_name):
        # Reset all buttons
        for btn in self.nav_buttons.values():
            btn.configure(fg_color="transparent")
        
        # Highlight active button
        if page_name in self.nav_buttons:
            self.nav_buttons[page_name].configure(fg_color="#1e3a8a")
        
        self.active_page = page_name
    
    def update_aura_points(self, points):
        self.aura_label.configure(text=str(points))
        # Update level info as well
        level, level_info = self.level_system.get_current_level(points)
        self.level_label.configure(text=f"Level {level} • {level_info['title']}")