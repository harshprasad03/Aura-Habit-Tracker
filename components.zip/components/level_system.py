# components/level_system.py
class LevelSystem:
    LEVELS = {
        1: {"points": 0, "title": "Beginner", "color": "#6b7280", "aura_color": "#ffcc00"},
        2: {"points": 100, "title": "Apprentice", "color": "#10b981", "aura_color": "#ff6600"},
        3: {"points": 300, "title": "Adept", "color": "#3b82f6", "aura_color": "#ff3366"},
        4: {"points": 600, "title": "Expert", "color": "#8b5cf6", "aura_color": "#9933ff"},
        5: {"points": 1000, "title": "Master", "color": "#f59e0b", "aura_color": "#00ffff"},
        6: {"points": 1500, "title": "Grand Master", "color": "#ef4444", "aura_color": "#ffffff"}
    }
    
    def get_current_level(self, aura_points):
        for level, info in reversed(self.LEVELS.items()):
            if aura_points >= info["points"]:
                return level, info
        return 1, self.LEVELS[1]
    
    def get_level_progress(self, aura_points):
        current_level, current_info = self.get_current_level(aura_points)
        
        if current_level == 6:  # Max level
            return 1.0
        
        next_level_points = self.LEVELS[current_level + 1]["points"]
        current_level_points = current_info["points"]
        
        progress = (aura_points - current_level_points) / (next_level_points - current_level_points)
        return min(progress, 1.0)