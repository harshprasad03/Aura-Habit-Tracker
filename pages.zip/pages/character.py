# pages/character.py
import customtkinter as ctk
from PIL import Image, ImageTk
import os
from components.level_system import LevelSystem

class CharacterPage(ctk.CTkFrame):
    def __init__(self, parent, data):
        super().__init__(parent, corner_radius=15)
        self.data = data
        self.character_images = {}
        self.setup_character_page()
    
    def setup_character_page(self):
        # Configure grid
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)
        
        # Header
        header_frame = ctk.CTkFrame(self, corner_radius=12, height=80)
        header_frame.grid(row=0, column=0, sticky="ew", padx=20, pady=20)
        header_frame.grid_propagate(False)
        
        ctk.CTkLabel(header_frame, text="🎭 Your Character", 
                    font=("Arial", 24, "bold")).pack(pady=20)
        
        # Main content
        content_frame = ctk.CTkFrame(self, corner_radius=12)
        content_frame.grid(row=1, column=0, sticky="nsew", padx=20, pady=(0, 20))
        content_frame.grid_columnconfigure(0, weight=1)
        content_frame.grid_rowconfigure(0, weight=1)
        
        # Character display area
        self.character_display = ctk.CTkFrame(content_frame, corner_radius=15)
        self.character_display.grid(row=0, column=0, sticky="nsew", padx=20, pady=20)
        self.character_display.grid_columnconfigure(0, weight=1)
        self.character_display.grid_rowconfigure(1, weight=1)
        
        # Aura level info
        aura_info = ctk.CTkFrame(self.character_display, corner_radius=10, fg_color="#1e3a8a")
        aura_info.grid(row=0, column=0, sticky="ew", padx=20, pady=20)
        
        aura_points = self.data.get("aura_points", 0)
        ctk.CTkLabel(aura_info, text="AURA POWER LEVEL", 
                    font=("Arial", 16, "bold"), text_color="#93c5fd").pack(pady=(10, 5))
        ctk.CTkLabel(aura_info, text=str(aura_points), 
                    font=("Arial", 32, "bold"), text_color="#ffffff").pack(pady=(0, 10))
        
        # Level system info
        level_system = LevelSystem()
        level, level_info = level_system.get_current_level(aura_points)
        progress = level_system.get_level_progress(aura_points)
        
        ctk.CTkLabel(aura_info, text=f"Level {level}: {level_info['title']}", 
                    font=("Arial", 14), text_color=level_info["color"]).pack(pady=5)
        ctk.CTkLabel(aura_info, text=f"Progress to next level: {int(progress*100)}%", 
                    font=("Arial", 12)).pack(pady=(0, 10))
        
        # Character canvas
        self.canvas = ctk.CTkCanvas(self.character_display, width=400, height=400, 
                                   bg="#2a2a2a", highlightthickness=0)
        self.canvas.grid(row=1, column=0, pady=20)
        
        # Character selection
        selection_frame = ctk.CTkFrame(content_frame, corner_radius=10)
        selection_frame.grid(row=1, column=0, sticky="ew", padx=20, pady=(0, 20))
        
        ctk.CTkLabel(selection_frame, text="Choose Your Warrior", 
                    font=("Arial", 18, "bold")).pack(pady=15)
        
        buttons_frame = ctk.CTkFrame(selection_frame, fg_color="transparent")
        buttons_frame.pack(pady=10)
        
        characters = [
            ("Goku", "Goku", "The Determined Saiyan"),
            ("Vegeta", "Vegeta", "The Proud Prince"), 
            ("Gohan", "Gohan", "The Scholarly Warrior"),
            ("Piccolo", "Piccolo", "The Wise Namekian"),
            ("Frieza", "Frieza", "The Cunning Emperor")
        ]
        
        for i, (name, key, desc) in enumerate(characters):
            char_frame = ctk.CTkFrame(buttons_frame, corner_radius=8)
            char_frame.grid(row=0, column=i, padx=10, pady=10)
            
            ctk.CTkButton(char_frame, text=name, 
                         command=lambda k=key: self.select_character(k),
                         width=120, height=40).pack(padx=10, pady=10)
            ctk.CTkLabel(char_frame, text=desc, font=("Arial", 10), 
                        text_color="gray").pack(padx=10, pady=(0, 10))
        
        # Load current character
        self.load_current_character()
    
    def load_current_character(self):
        current_char = self.data.get("character", "goku")
        self.select_character(current_char)
    
    def select_character(self, character_key):
        self.data["character"] = character_key
        self.display_character(character_key)
        self.draw_aura()
    
    def display_character(self, character_key):
        self.canvas.delete("all")
        
        # Try to load character image
        try:
            image_path = f"assets/{character_key}.png"
            if os.path.exists(image_path):
                img = Image.open(image_path).resize((300, 300))
                self.character_images[character_key] = ImageTk.PhotoImage(img)
                self.canvas.create_image(200, 200, image=self.character_images[character_key])
            else:
                # Fallback: Draw simple character
                self.draw_fallback_character(character_key)
        except Exception as e:
            self.draw_fallback_character(character_key)
    
    def draw_fallback_character(self, character_key):
        # Draw a simple representation of the character
        colors = {
            "goku": "#ff6b00",
            "vegeta": "#0055ff", 
            "gohan": "#ffaa00",
            "piccolo": "#00aa44",
            "frieza": "#aa00ff"
        }
        
        color = colors.get(character_key, "#666666")
        
        # Draw simple character silhouette
        self.canvas.create_oval(150, 100, 250, 200, fill=color, outline="")
        self.canvas.create_rectangle(175, 200, 225, 300, fill=color, outline="")
        self.canvas.create_text(200, 350, text=character_key.upper(), 
                               fill="white", font=("Arial", 16, "bold"))
    
    def draw_aura(self):
        aura_points = self.data.get("aura_points", 0)
        self.canvas.delete("aura")
        
        if aura_points > 0:
            level_system = LevelSystem()
            level, level_info = level_system.get_current_level(aura_points)
            
            base_radius = 120
            aura_radius = base_radius + (aura_points // 20)
            aura_color = level_info["aura_color"]
            
            # Draw multiple glowing layers
            for i in range(5):
                radius = aura_radius + i * 8
                self.canvas.create_oval(
                    200 - radius, 200 - radius,
                    200 + radius, 200 + radius,
                    outline=aura_color, width=2, tags="aura",
                    dash=(4, 4) if i % 2 == 0 else None
                )