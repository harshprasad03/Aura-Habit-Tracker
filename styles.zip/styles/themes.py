# styles/themes.py
import customtkinter as ctk

def apply_modern_theme():
    ctk.set_appearance_mode("Dark")
    ctk.set_default_color_theme("blue")