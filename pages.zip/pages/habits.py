# pages/habits.py - COMPLETE UPDATED VERSION
import customtkinter as ctk
from tkinter import messagebox
from datetime import datetime
from data_handler import add_habit, mark_habit_done, save_data

class HabitsPage(ctk.CTkFrame):
    def __init__(self, parent, data):
        super().__init__(parent, corner_radius=15)
        self.data = data
        self.setup_habits_page()
    
    def setup_habits_page(self):
        # Configure grid
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)
        
        # Header with add button
        header_frame = ctk.CTkFrame(self, corner_radius=12, height=80)
        header_frame.grid(row=0, column=0, sticky="ew", padx=20, pady=20)
        header_frame.grid_columnconfigure(1, weight=1)
        header_frame.grid_propagate(False)
        
        ctk.CTkLabel(header_frame, text="Your Habits", 
                    font=("Arial", 24, "bold")).grid(row=0, column=0, padx=20, pady=20, sticky="w")
        
        ctk.CTkButton(header_frame, text="+ Add New Habit", 
                     command=self.show_add_habit_dialog,
                     font=("Arial", 14), height=40).grid(row=0, column=1, padx=20, pady=20, sticky="e")
        
        # Habits list
        self.habits_container = ctk.CTkScrollableFrame(self, corner_radius=12)
        self.habits_container.grid(row=1, column=0, sticky="nsew", padx=20, pady=(0, 20))
        self.habits_container.grid_columnconfigure(0, weight=1)
        
        self.refresh_habits_list()
    
    def refresh_habits_list(self):
        # Clear existing habits
        for widget in self.habits_container.winfo_children():
            widget.destroy()
        
        habits = self.data.get("habits", [])
        
        if not habits:
            # Show empty state
            empty_frame = ctk.CTkFrame(self.habits_container, corner_radius=10, height=200)
            empty_frame.grid(row=0, column=0, sticky="ew", padx=10, pady=10)
            empty_frame.grid_columnconfigure(0, weight=1)
            
            ctk.CTkLabel(empty_frame, text="📝", font=("Arial", 48)).pack(pady=(30, 10))
            ctk.CTkLabel(empty_frame, text="No habits yet!", 
                        font=("Arial", 18, "bold")).pack(pady=5)
            ctk.CTkLabel(empty_frame, text="Add your first habit to start building your aura",
                        font=("Arial", 14), text_color="gray").pack(pady=5)
            ctk.CTkButton(empty_frame, text="Create First Habit",
                         command=self.show_add_habit_dialog).pack(pady=20)
            return
        
        # Display habits
        for i, habit in enumerate(habits):
            self.create_habit_card(habit, i)
    
    def create_habit_card(self, habit, index):
        card = ctk.CTkFrame(self.habits_container, corner_radius=15, 
                       fg_color=("gray90", "gray13"), height=100)
        card.grid(row=index, column=0, sticky="ew", padx=10, pady=8)
        card.grid_columnconfigure(1, weight=1)
        card.grid_propagate(False)
        
        # Progress ring with better styling
        canvas = ctk.CTkCanvas(card, width=70, height=70, highlightthickness=0, 
                          bg='#2b2b2b' if ctk.get_appearance_mode() == "Dark" else 'white')
        canvas.grid(row=0, column=0, padx=20, pady=15)
        
        # Draw enhanced progress ring
        streak = habit.get('streak', 0)
        progress = min(streak / 7, 1.0)
        
        # Progress ring drawing
        canvas.delete("progress")
        # Background circle
        canvas.create_oval(35-25, 35-25, 35+25, 35+25, 
                      outline="#374151", width=4, tags="progress")
        # Progress arc
        if progress > 0:
            extent = 360 * progress
            color = "#10b981" if streak >= 7 else "#3b82f6"
            canvas.create_arc(35-25, 35-25, 35+25, 35+25,
                         start=90, extent=-extent, outline=color, 
                         width=4, style="arc", tags="progress")
        # Center text
        canvas.create_text(35, 35, text=str(streak), font=("Arial", 14, "bold"), 
                      fill="white" if ctk.get_appearance_mode() == "Dark" else "black", 
                      tags="progress")
        
        # Habit info with better layout
        info_frame = ctk.CTkFrame(card, fg_color="transparent")
        info_frame.grid(row=0, column=1, sticky="nsew", padx=10, pady=15)
        info_frame.grid_columnconfigure(0, weight=1)
        
        ctk.CTkLabel(info_frame, text=habit["name"], 
                font=("Arial", 18, "bold")).grid(row=0, column=0, sticky="w")
        
        # Enhanced stats with icons
        category = habit.get("category", "General")
        completions = habit.get("total_completions", 0)
        
        stats_frame = ctk.CTkFrame(info_frame, fg_color="transparent")
        stats_frame.grid(row=1, column=0, sticky="w", pady=(5, 0))
        
        fire_size = "🔥" * min(3, (streak // 3) + 1)
        ctk.CTkLabel(stats_frame, text=f"{fire_size} {streak}d", 
                font=("Arial", 12), text_color="#f59e0b").pack(side="left", padx=(0, 10))
        ctk.CTkLabel(stats_frame, text=f"🎯 {completions}", 
                font=("Arial", 12), text_color="#3b82f6").pack(side="left", padx=(0, 10))
        ctk.CTkLabel(stats_frame, text=f"📁 {category}", 
                font=("Arial", 12), text_color="gray").pack(side="left")
        
        # Enhanced complete button
        btn_color = "#22c55e" if streak > 0 else "#3b82f6"
        ctk.CTkButton(card, text="✓ Complete", 
                 command=lambda h=habit["name"]: self.complete_habit(h),
                 width=120, height=40, fg_color=btn_color, 
                 hover_color="#16a34a", font=("Arial", 14, "bold")
                 ).grid(row=0, column=2, padx=20, pady=15)
    
    def show_add_habit_dialog(self):
        dialog = ctk.CTkToplevel(self)
        dialog.title("Add New Habit")
        dialog.geometry("400x300")
        dialog.resizable(False, False)
        dialog.transient(self)
        dialog.grab_set()
        
        # Center the dialog
        dialog.update_idletasks()
        x = self.winfo_x() + (self.winfo_width() - dialog.winfo_width()) // 2
        y = self.winfo_y() + (self.winfo_height() - dialog.winfo_height()) // 2
        dialog.geometry(f"+{x}+{y}")
        
        ctk.CTkLabel(dialog, text="Create New Habit", 
                    font=("Arial", 20, "bold")).pack(pady=20)
        
        # Habit name
        ctk.CTkLabel(dialog, text="Habit Name:", 
                    font=("Arial", 14)).pack(anchor="w", padx=30, pady=(10, 5))
        name_entry = ctk.CTkEntry(dialog, placeholder_text="e.g., Morning Meditation", 
                                 font=("Arial", 14), height=40)
        name_entry.pack(fill="x", padx=30, pady=5)
        name_entry.focus()
        
        # Category
        ctk.CTkLabel(dialog, text="Category:", 
                    font=("Arial", 14)).pack(anchor="w", padx=30, pady=(15, 5))
        category_var = ctk.StringVar(value="General")
        category_frame = ctk.CTkFrame(dialog, fg_color="transparent")
        category_frame.pack(fill="x", padx=30, pady=5)
        
        categories = ["General", "Health", "Productivity", "Learning", "Mindfulness", "Fitness"]
        for i, category in enumerate(categories):
            btn = ctk.CTkRadioButton(category_frame, text=category, variable=category_var, value=category)
            btn.grid(row=0, column=i, padx=5)
        
        # Buttons
        button_frame = ctk.CTkFrame(dialog, fg_color="transparent")
        button_frame.pack(side="bottom", fill="x", padx=30, pady=20)
        
        ctk.CTkButton(button_frame, text="Cancel", 
                     command=dialog.destroy, fg_color="transparent",
                     border_width=2, text_color=("gray10", "gray90")).pack(side="right", padx=10)
        
        ctk.CTkButton(button_frame, text="Create Habit", 
                     command=lambda: self.create_habit(name_entry.get(), category_var.get(), dialog)).pack(side="right")
    
    def create_habit(self, name, category, dialog):
        if not name.strip():
            messagebox.showerror("Error", "Please enter a habit name")
            return
        
        add_habit(self.data, name.strip(), category)
        self.refresh_habits_list()
        messagebox.showinfo("Success", f"Habit '{name}' added!")
        dialog.destroy()
    
    def complete_habit(self, habit_name):
        new_points = mark_habit_done(self.data, habit_name)
        self.refresh_habits_list()
        
        # Show celebration message
        messagebox.showinfo("Aura Boost! ⚡", 
                          f"Completed '{habit_name}'!\n"
                          f"+10 Aura Points\n"
                          f"Total: {new_points}")