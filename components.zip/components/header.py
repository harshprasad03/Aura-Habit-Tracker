# components/header.py
import customtkinter as ctk
from datetime import datetime

class AppHeader(ctk.CTkFrame):
    def __init__(self, parent, switch_callback):
        super().__init__(parent, corner_radius=10, height=60)
        self.switch_callback = switch_callback
        self.setup_header()
    
    def setup_header(self):
        self.grid_columnconfigure(1, weight=1)
        
        # App logo/title
        ctk.CTkLabel(self, text="⚡ Aura Habit Tracker", 
                    font=("Arial", 24, "bold")).grid(row=0, column=0, padx=20, pady=10, sticky="w")
        
        # Current date
        self.date_label = ctk.CTkLabel(self, text="", font=("Arial", 14))
        self.date_label.grid(row=0, column=1, padx=20, pady=10)
        self.update_date()
        
        # Theme toggle
        self.theme_btn = ctk.CTkButton(self, text="🌙", width=40, height=40,
                                      command=self.switch_callback, font=("Arial", 16))
        self.theme_btn.grid(row=0, column=2, padx=20, pady=10)
    
    def update_date(self):
        current_date = datetime.now().strftime("%A, %B %d, %Y")
        self.date_label.configure(text=current_date)
        self.after(60000, self.update_date)  # Update every minute
    
    def update_theme_button(self, mode):
        self.theme_btn.configure(text="☀️" if mode == "Light" else "🌙")