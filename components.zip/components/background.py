# components/background.py
import customtkinter as ctk
import random

class AnimatedBackground(ctk.CTkCanvas):
    def __init__(self, parent):
        super().__init__(parent, highlightthickness=0)
        self.config(bg='#0f0f23')
        self.place(relwidth=1, relheight=1)
        self.particles = []
        self.create_particles()
        self.animate_particles()
    
    def create_particles(self):
        for _ in range(30):
            x = random.randint(0, 1200)
            y = random.randint(0, 800)
            size = random.randint(1, 2)
            particle = self.create_oval(x, y, x+size, y+size, fill='#1e3a8a', outline='', tags="particle")
            self.particles.append(particle)
    
    def animate_particles(self):
        for particle in self.particles:
            self.move(particle, 0, 1)
            coords = self.coords(particle)
            if coords[1] > 800:
                self.coords(particle, random.randint(0, 1200), -10, 
                           random.randint(0, 1200)+2, -8)
        self.after(50, self.animate_particles)